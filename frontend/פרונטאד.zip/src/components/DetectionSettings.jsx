/*
 * DetectionSettings.jsx
 * בחירת רמה (🧘🤨😤) של זיהוי הונאות
 * קומפוננטה לבחירת רמת זיהוי הונאות.
 * מציגה 3 אופציות עם emoji, תיאור, ו-use cases.
 * שומרת את הבחירה ב-database.
 */
import { useState, useEffect } from 'react';

function DetectionSettings({ accountId }) {
  const [presets, setPresets] = useState([]);
  const [selectedPreset, setSelectedPreset] = useState('balanced');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadPresets();
    if (accountId) {
      loadAccountSettings();
    } else {
      setLoading(false);
    }
  }, [accountId]);

  const loadPresets = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:3001/api/detection/presets', {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!response.ok) throw new Error('Failed to load presets');

      const data = await response.json();
      setPresets(data.presets || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading presets:', error);
      setLoading(false);
    }
  };

  const loadAccountSettings = async () => {
    if (!accountId) return;

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:3001/api/googleads/accounts', {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!response.ok) throw new Error('Failed to load account');

      const data = await response.json();
      const account = data.accounts?.find(a => a.id === accountId);
      
      if (account?.detection_preset) {
        setSelectedPreset(account.detection_preset);
      }
    } catch (error) {
      console.error('Error loading account settings:', error);
    }
  };

  const handleSaveSettings = async () => {
    if (!accountId) return;

    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:3001/api/detection/${accountId}/settings`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ preset: selectedPreset })
        }
      );

      if (!response.ok) throw new Error('Failed to save settings');

      alert('✅ הגדרות נשמרו בהצלחה!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('❌ שגיאה בשמירת הגדרות');
    } finally {
      setSaving(false);
    }
  };

  const getPresetColor = (presetId) => {
    switch (presetId) {
      case 'liberal':
        return 'from-green-500 to-teal-500';
      case 'balanced':
        return 'from-[var(--color-cyan)] to-[var(--color-purple)]';
      case 'aggressive':
        return 'from-red-500 to-orange-500';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const getPresetBorder = (presetId) => {
    switch (presetId) {
      case 'liberal':
        return 'border-green-500/50';
      case 'balanced':
        return 'border-[var(--color-cyan)]/50';
      case 'aggressive':
        return 'border-red-500/50';
      default:
        return 'border-white/20';
    }
  };

  if (!accountId) {
    return (
      <div className="glass-strong rounded-2xl p-12 border border-white/10 text-center">
        <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-[var(--color-cyan)] to-[var(--color-purple)] rounded-full flex items-center justify-center opacity-50">
          <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
          </svg>
        </div>
        <h3 className="text-2xl font-bold text-white mb-3">⚙️ הגדרות זיהוי הונאות</h3>
        <p className="text-[var(--color-text-secondary)] mb-4">
          כאן תוכלו לבחור את רמת הרגישות של מערכת זיהוי ההונאות:
        </p>
        <div className="flex justify-center gap-4 mb-6 text-sm">
          <div className="glass rounded-lg p-3 border border-white/10">
            <div className="text-2xl mb-1">🧘</div>
            <p className="text-[var(--color-text-secondary)]">רגוע על מלא</p>
          </div>
          <div className="glass rounded-lg p-3 border border-white/10">
            <div className="text-2xl mb-1">🤨</div>
            <p className="text-[var(--color-text-secondary)]">חשדן בקטנה</p>
          </div>
          <div className="glass rounded-lg p-3 border border-white/10">
            <div className="text-2xl mb-1">😤</div>
            <p className="text-[var(--color-text-secondary)]">בלי חרטות</p>
          </div>
        </div>
        <p className="text-[var(--color-text-tertiary)] text-sm mb-6">
          כדי להגדיר את הרמה, חברו את חשבון Google Ads שלכם
        </p>
        <button
          onClick={() => window.location.href = '/app/connect-ads'}
          className="px-8 py-4 bg-gradient-to-r from-[var(--color-cyan)] to-[var(--color-purple)] rounded-xl text-white font-bold hover:scale-105 transition-transform"
        >
          חברו עכשיו →
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="glass-strong rounded-2xl p-8 border border-white/10">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[var(--color-cyan)]/20 border-t-[var(--color-cyan)] rounded-full animate-spin mx-auto mb-4" />
          <p className="text-[var(--color-text-secondary)]">טוען הגדרות...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-strong rounded-2xl border border-white/10 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[var(--color-purple)] to-[var(--color-magenta)] rounded-xl flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
            </svg>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">רמת זיהוי הונאות</h3>
            <p className="text-sm text-[var(--color-text-secondary)]">
              בחרו את רמת הרגישות שמתאימה לכם
            </p>
          </div>
        </div>
      </div>

      {/* Presets Grid */}
      <div className="p-6">
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {presets.map((preset) => (
            <button
              key={preset.id}
              onClick={() => setSelectedPreset(preset.id)}
              className={`relative group p-6 glass rounded-2xl border-2 transition-all hover:scale-105 ${
                selectedPreset === preset.id
                  ? `${getPresetBorder(preset.id)} bg-white/5`
                  : 'border-white/10 hover:border-white/20'
              }`}
            >
              {/* Selected Badge */}
              {selectedPreset === preset.id && (
                <div className="absolute -top-3 -right-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-[var(--color-success)] to-[var(--color-cyan)] rounded-full flex items-center justify-center">
                    <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                </div>
              )}

              {/* Recommended Badge */}
              {preset.recommended && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <div className="px-3 py-1 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full text-xs font-bold text-white whitespace-nowrap">
                    ⭐ מומלץ
                  </div>
                </div>
              )}

              {/* Icon */}
              <div className={`w-20 h-20 mx-auto mb-4 bg-gradient-to-br ${getPresetColor(preset.id)} rounded-2xl flex items-center justify-center text-4xl`}>
                {preset.emoji}
              </div>

              {/* Title */}
              <h4 className="text-xl font-bold text-white mb-2">{preset.name}</h4>

              {/* Description */}
              <p className="text-sm text-[var(--color-text-secondary)] mb-4">
                {preset.description}
              </p>

              {/* Use Cases */}
              <div className="space-y-2">
                <p className="text-xs text-[var(--color-text-tertiary)] font-bold">מתאים ל:</p>
                {preset.useCases?.slice(0, 2).map((useCase, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[var(--color-cyan)] rounded-full mt-1.5 flex-shrink-0" />
                    <p className="text-xs text-[var(--color-text-secondary)]">{useCase}</p>
                  </div>
                ))}
              </div>

              {/* Rules Count */}
              <div className="mt-4 pt-4 border-t border-white/10">
                <p className="text-xs text-[var(--color-text-tertiary)]">
                  {Object.keys(preset.rules || {}).length} כללי זיהוי פעילים
                </p>
              </div>
            </button>
          ))}
        </div>

        {/* Save Button */}
        <div className="flex justify-center">
          <button
            onClick={handleSaveSettings}
            disabled={saving}
            className="px-12 py-4 bg-gradient-to-r from-[var(--color-cyan)] to-[var(--color-purple)] text-white font-bold text-lg rounded-xl hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl"
          >
            {saving ? (
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin" />
                <span>שומר...</span>
              </div>
            ) : (
              '💾 שמור הגדרות'
            )}
          </button>
        </div>

        {/* Info Box */}
        <div className="mt-8 p-6 glass rounded-2xl border border-[var(--color-cyan)]/30">
          <div className="flex gap-4">
            <div className="w-12 h-12 bg-[var(--color-cyan)]/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <svg className="w-6 h-6 text-[var(--color-cyan)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h5 className="text-white font-bold mb-2">💡 טיפ מקצועי</h5>
              <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">
                מומלץ להתחיל עם רמת "חשדן בקטנה" ואז להתאים בהתאם לתוצאות. 
                אם אתם רואים הרבה False Positives - עברו ל"רגוע על מלא". 
                אם אתם סובלים מהונאות כבדות - עברו ל"בלי חרטות".
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DetectionSettings;